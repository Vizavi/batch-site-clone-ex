    import { createElement, appendChilds } from "../../src/etc/utils";

    export const progressForm = (title = 'Tytle is missing', textData = 'No data') => {
    const flow = createElement('div', {class: 'flow-root rounded-lg border border-gray-100 py-3 shadow-sm'});
    const lines = createElement('dl', {class: '-my-3 divide-y divide-gray-100 text-sm'});
    const casesTotal = titleRow('casesTotal', 'Progress:  ', 'Planned/Success/Failes');
    const processingStatus = titleRow('processingStatus', 'Current Status', 'N/A');
    const timeSpent = titleRow('timeSpent', 'Time spent', '0');
    const form =  appendChilds(lines, casesTotal.htmlElement, processingStatus.htmlElement, timeSpent.htmlElement);
   flow.appendChild(form);

    return {
        htmlElement: flow,
        setValue: (value) => {
            casesTotal.setValue(`  ${value.total}/ ${value.success}/ ${value.failed}  (planned/success/failes)`);
            processingStatus.setValue(value.processingStatus);
            timeSpent.setValue(Date.now() - value.startTime);
        },
        getValue: () => {
            return {
                total: casesTotal.getValue(),
                processingStatus: processingStatus.getValue(),
                timeSpent: timeSpent.getValue(),
            }
        }
    
    }
}


function titleRow (id, title, value) {
    const row = createElement('div', {groupId:`group-${id}`, class: 'grid grid-cols-1 gap-1 p-3 even:bg-gray-50 sm:grid-cols-3 sm:gap-4'});
    const rowTitle = createElement('dt', {groupId:`group-${id}`, class: 'font-medium text-gray-900', innerText:title});
    const rowData = createElement('dd', {groupId:`group-${id}`, id:id, class: 'text-gray-700 sm:col-span-2', innerText: value});
    const titleRow = appendChilds(row, rowTitle, rowData);
    return     {
        htmlElement: titleRow,
        setValue:(value) =>{rowData.innerText = value},
        getValue:() => rowData.innerText,
    }
}