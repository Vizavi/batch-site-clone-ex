export const remoteUser = {
    userId:`b5d67212-f61e-47ac-b10d-7bd67bafbb6b`,
    isWix:true,
    userEmail: 'olololo@wix.com',
    displayName:'Test Matrix',
    targetOption: 'remoteUser',
}