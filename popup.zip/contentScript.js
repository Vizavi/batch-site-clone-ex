//document.addEventListener('DOMContentLoaded', function() { /* ... */ }) 
import { getCurrentUserData } from './common/src/etc/authAndCookies.js';
import { cloneSite } from './common/cloneSite.js';
import { appendChilds, parseStringToArray, createElement, paragraph, nestedElements, groupAndAlignElements } from './common/src/etc/utils.js';
import { labledTextInput, labledTextArea, getTabPanel, getButtonGroup, spoileredElement, newButton} from './common/src/components/forms.js';
import { TEXT } from './common/constrains.js';
import { footer } from './common/src/components/baseElemnts.js';
import { remoteUser } from './common/remoteUserConfig.js';
import { sidePanel } from './common/src/forms/sidePanelBase.js';
import { onClickEvents } from './common/src/events/click.js';
import { init } from './common/src/forms/defaultState.js';
import { progressForm } from './common/src/forms/progressForm.js';

const backOfficeLink = 'ui.shadcn.com';


const {thisUser, thisProcessing, thisLocation, viewStates} = init();


 chrome.runtime.onMessage.addListener(handleMessage);

const footerDiv = footer();
const progrFrom = progressForm('Stupid tytle!!', 'Some text data 10/10');
const currentUserInput = labledTextInput('currentUserId', 'Current User', 'Current user', '', true);
const textButtonsUnderMSID = getButtonGroup();
const msidList = labledTextArea('msidList', 'MSID List', TEXT.PLACEHOLDER.MSID_LIST, '', false, textButtonsUnderMSID, updateProcessingOnMSIDListChange);
const tabPanel = getTabPanel();
const siteNameTemplate = labledTextInput('clonnedSiteName', 'Name template for the clonned sites', `'cln-' + %MSID(8)%`, `'cln-' + %MSID(8)%`, true);
const spoiler = spoileredElement('Difinition, avalible variables, etc',  paragraph(TEXT.DESCRIPTION.SITE_NAME_TEMPLATE_DEFINITION));
const cloneButton = newButton('start-clone-button', "Start cloning", '', true);
const closeButton = newButton('close-progressForm-button', "Close", '', false);

progrFrom.htmlElement.appendChild(closeButton.htmlElement);

function getParsedMSIDList () {
    const rawMsidList = msidList.getValue()
    if (rawMsidList.length < 1 ) return false;
    return parseStringToArray(rawMsidList);
}

function updateProcessingOnMSIDListChange () {
    thisProcessing.msidList = getParsedMSIDList();
    thisProcessing.casesTotal = thisProcessing.msidList.length;
}

export function updateProgressForm () {
    const value = {
        total:thisProcessing.casesTotal,
        success:thisProcessing.casesSuccess,
        failed:thisProcessing.casesFailed,
        processingStatus: 'Cloning in progress',
        startTime: thisProcessing.startTime,
    }
    progrFrom.setValue(value);
}

const extensionPanel = sidePanel(viewStates);
document.body.insertAdjacentElement('beforeend', extensionPanel.htmlElement);

extensionPanel.htmlElement.appendChild(footerDiv);

extensionPanel.fullPanel.progressForm.appendChild(progrFrom.htmlElement);

extensionPanel.fullPanel.inputForm.appendChild(currentUserInput.htmlElement);
extensionPanel.fullPanel.inputForm.appendChild(msidList.htmlElement);
extensionPanel.fullPanel.inputForm.appendChild(tabPanel);
extensionPanel.fullPanel.inputForm.appendChild(siteNameTemplate.htmlElement);
extensionPanel.fullPanel.inputForm.appendChild(spoiler);
extensionPanel.fullPanel.inputForm.appendChild(cloneButton.htmlElement);

async function handleMessage(message, sender, sendResponse) {
    console.log("Received message from background script", message); 

    if (message.action === "toggleSidePanel") {
        if (extensionPanel.htmlElement.classList.contains('hidden')) {
            
           // console.log('Shjow side panel')
            extensionPanel.show.sidePanel();
            
            if (thisLocation.isBackOffice) {
                extensionPanel.show.inputForm();
                await getCurrentUserData(thisUser);
                currentUserInput.setValue('Alalalal');
            } else {
                extensionPanel.show.panelMessageForm();
             // extensionPanel.show.progressForm();
            }
            
            console.log('location: ', thisLocation);
            
        } else {
          //  console.log('Hide side panel');
            extensionPanel.hide.sidePanel();
          //  locationDiv.remove();
        }
    }
}
   
onClickEvents(thisProcessing, thisUser, remoteUser, msidList, cloneButton, extensionPanel);

// document.addEventListener('click', function(event) {
//     const targetClass = event.target.classList;
//     if (targetClass.contains('option-button')) {
//         handleOptionButtonClick(event);
//     } else if (targetClass.contains('text-button')) {
//         handleTextButtonClick(event);
//     } else if (targetClass.contains('start-clone-button')) {
//         handleCloneButtonClick(event);
//     }
// });
/*


messageDiv.addEventListener('click', () => {
    const validationLinke = 'https';

if (currentURL.includes(validationLinke)) {
    messageDiv.classList.add('hidden'); 
   // sidePanelGrid.appendChild(labledInput);
    sidePanelGrid.appendChild(msidListColl);
    sidePanelGrid.appendChild(executeBtn);
} else {
    window.open(validationLinke, '_blank');
    messageDiv.classList.remove('hidden');
    sidePanelGrid.appendChild(messageDiv);
}
});

// Attach event listeners
document.getElementById('slider').addEventListener('input', handleSliderInput);
// Assuming buttons have a common class 'option-button'
document.querySelectorAll('.option-button').forEach(button => {
    button.addEventListener('click', handleButtonClick);
});

function updateButtons(selectedOption) {
    document.querySelectorAll('.option-button').forEach(button => {
        const option = button.getAttribute('data-target-option');
        button.className = option === selectedOption ? selectedOptionClass : notSelectedOptionClass;
    });
}

function handleSliderInput(event) {
    thisUser.targetOption = event.target.value;
    updateButtons(thisUser.targetOption);
}

function handleButtonClick(event) {
    const button = event.target;
    thisUser.targetOption = button.getAttribute('data-target-option');
    document.getElementById('slider').value = thisUser.targetOption;
    updateButtons(thisUser.targetOption);
}


const findElementAndAttachEventListener = (id, eventType, handler) => {
    const element = document.getElementById('some-element-id');
if (element) {
    element.addEventListener('click', someFunction);
} else {
    console.error('Element not found');
}
}


slider.addEventListener('input', handleSliderInput);

document.getElementById('executeBtn').addEventListener('click', handleExecuteClick);

document.addEventListener('click', function(event) {
    if (event.target.classList.contains('option-button')) {
        handleButtonClick(event);
    }
});

//ocument.body.appendChild(sidePanel);
document.addEventListener('click', function(event) {
    if (event.target.id === 'executeBtn') {
        handleExecuteClick();
    }
});
*/
// executeBtn.addEventListener('click', async () => {
//     if (thisUser.isWix) {
//         const targetUserId = userIdList[targetOption];
//         msidList2 = await parseStringToArray(msidList.value);
//         executeBtn.disabled = true;

//         grid.classList.add('hidden');
//         sidePanelGrid.appendChild(spinner2);


//        // sidePanelPreloader.classList.remove('hidden');
//         //sidePanelPreloader.classList.remove('hidden');
//         for (const msid of msidList2) {
//             await cloneSite(msid, targetUserId);
//         }
//         executeBtn.disabled = false;
//     }
// });